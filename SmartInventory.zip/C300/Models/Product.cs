﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace C300.Models
{
    public class Product
    {   public int Id { get; set; }

        [Required(ErrorMessage ="Enter a description")]
        [StringLength(50, ErrorMessage = "Maximum is 50 Characters")]
        public string Description { get; set; }

        public double Weight { get; set; }

        public double Width { get; set; }

        public double Height { get; set; }

        public double Depth { get; set; }

        public int PackageId { get; set; }

        //[Required(ErrorMessage = "Enter a package type")]
        //[StringLength(50, ErrorMessage = "Maximum is 50 Characters")]
        public string Type { get; set; }

        public int CategoryId{ get; set; }

        //[Required(ErrorMessage = "Enter a category")]
        //[StringLength(50, ErrorMessage = "Maximum is 50 Characters")]
        public string CategoryDescription { get; set; }

        public int LocationId { get; set; }
        
        //[Required]
        public string Isle { get; set; }
        
        //[Required]
        public string Shelf { get; set; }

        public int Quantity { get; set; }

        public string Image { get; set; }

        //[Required(ErrorMessage = "Please select Photo")]
        //public IFormFile Photo { get; set; }

        public int ReplenishmentId { get; set; }

        [Required(ErrorMessage = "Please enter Restock Date Time")]
        [DataType(DataType.Date)]
        public DateTime RestockDate { get; set; }

        public int month { get; set; }
    }
}
