﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace C300.Models
{
    public class Product2
    {
        [Required(ErrorMessage = "Enter a description")]
        [StringLength(50, ErrorMessage = "Maximum is 50 Characters")]
        public string Description { get; set; }

        public int month { get; set; }
    }
}
