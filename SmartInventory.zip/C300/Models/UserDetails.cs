﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace C300.Models
{
    public class UserDetails
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Please enter Employee No")]
        public string EmployeeNo { get; set; }

        [Required(ErrorMessage = "Please enter Last Name")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Please enter Given Name")]
        public string GivenName { get; set; }

        public string OtherNames { get; set; }

        [Required(ErrorMessage = "Please enter Dob")]
        [DataType(DataType.Date)]
        public DateTime Dob { get; set; }

        [Required (ErrorMessage = "Please enter password")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Compare("Password", ErrorMessage = "Passwords do not match")]
        [DataType(DataType.Password)]
        public string Password2{ get; set; }

        [Required(ErrorMessage = "Please select User Role")]
        public string UserRole { get; set; }

        public int CompanyId { get; set; }

        public string TradingAs { get; set; }

        //private HashCode password;

        //public HashCode GetPassword()
        //{
        //    return password;
        //}

        //public void SetPassword(HashCode value)
        //{
        //    password = value;
        //}
    }
}
