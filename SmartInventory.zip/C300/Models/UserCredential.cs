﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace C300.Models
{
    public class UserCredential
    {
        public string EmployeeNo { get; set; }
        public string Password { get; set; }
        public bool RememberMe { get; set; }
    }
}

