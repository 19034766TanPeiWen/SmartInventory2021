﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using C300.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace C300.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StockController : ControllerBase
    {
        [HttpGet]
        public IEnumerable<Stock> Get()
        {
            List<Stock> dbList = DBUtl.GetList<Stock>("SELECT Product.Id, Description, Isle, Shelf, Quantity, CONVERT(datetime, RestockDate) As RestockDate FROM Product, Location, Replenishment WHERE Product.LocationId = Location.Id AND Product.Id = Replenishment.ProductId  AND Quantity <=3");
            //List<Stock> dbList = DBUtl.GetList<Stock>("SELECT Product.Id, Description, Isle, Shelf, Quantity FROM Product, Location WHERE Product.LocationId = Location.Id AND Quantity <=3");
            return dbList;
        }
        [HttpPost]
        public IActionResult Post([FromBody]Stock product)
        {
            if (product == null)
            {
                return BadRequest("Parameters must not be null");
            }

            string sqlInsert = @"INSERT INTO Replenishment(ProductId, RestockDate) VALUES
                        ({0},CONVERT(varchar,'{1}'))"; 

            if (DBUtl.ExecSQL(sqlInsert, product.ProductId, product.RestockDate) == 1)
                return Ok();
            else
                return BadRequest(new { Message = DBUtl.DB_Message });
        }

        [HttpPut("{id}")]
        public IActionResult Put(string id, [FromBody] Stock product)
        {
            if (product == null || id == null)
            {
                return BadRequest();
            }

            string sql = @"UPDATE Product 
                              SET Quantity = {1}  
                              WHERE Product.Id= {0} ";
            string update = String.Format(sql, product.Id, product.Quantity);
            if (DBUtl.ExecSQL(update) == 1)
                return Ok();
            else
                return BadRequest(new { Message = DBUtl.DB_Message });

        }
    }
}
