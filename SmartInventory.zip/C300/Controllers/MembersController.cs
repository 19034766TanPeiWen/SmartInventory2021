﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using C300.Models;
using System.Collections.Generic;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace C300.Controllers
{
    [AllowAnonymous]
    [Route("api/[controller]")]
    [ApiController]
    public class MembersController : ControllerBase
    {
        private readonly IJwtAuth jwtAuth;
        private readonly List<UserDetails> dbList = DBUtl.GetList<UserDetails>
            ("SELECT Employee.Id, EmployeeNo, LastName, GivenName, OtherNames, Dob, CompanyId, TradingAs, CONVERT([varchar](512), Password, 2) as Password, UserRole FROM Employee, Company WHERE Employee.CompanyId = Company.Id");
        //private readonly List<Member> lstMember = new List<Member>()
        //{
        //    new Member{Id=1, Name="Kirtesh" },
        //    new Member {Id=2, Name="Nitya" },
        //    new Member{Id=3, Name="pankaj"}
        //};
        public MembersController(IJwtAuth jwtAuth)
        {
            this.jwtAuth = jwtAuth;
        }
        // GET: api/<MembersController>
        [HttpGet]
        public IEnumerable<UserDetails> AllMembers()
        {
            return dbList;
        }

        // GET api/<MembersController>/5
        [HttpGet("{id}")]
        public UserDetails MemberByid(string id)
        {
            return dbList.Find(x => x.EmployeeNo == id);
        }

        [AllowAnonymous]
        // POST api/<MembersController>
        [HttpPost("authentication")]
        public IActionResult Authentication([FromBody] UserCredential userCredential)
        {
            var token = jwtAuth.Authentication(userCredential.EmployeeNo, userCredential.Password);
            if (token == null)
                return Unauthorized();
            return Ok(token);
        }


    }
}