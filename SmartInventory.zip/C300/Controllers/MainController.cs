﻿using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using C300.Models;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections;
using System.Linq;

namespace SmartInventory.Controllers
{
    public class MainController : Controller
    {
        private IWebHostEnvironment _env;

        #region trends
        [HttpGet]
        public IActionResult trends()
        {
            return View();
        }

        [HttpPost]
        public IActionResult trendsPost(Product product)
        {
            IFormCollection form = HttpContext.Request.Form;
            string month = form["month"].ToString();
            product.month = Int32.Parse(month);
            return RedirectToAction("Chart", product);
        }
        #endregion
        #region Chart
        public IActionResult Chart(Product pdt)
        {
            int month = pdt.month;
            string sql = @"SELECT Distinct(Description) FROM Product, Replenishment
                         WHERE Product.Id = Replenishment.ProductId AND Month(RestockDate) ='{0}'";
            List<Product> list = DBUtl.GetList<Product>(sql, month);
            //string[] product = new string[] { };
            ArrayList<string> product2 = new ArrayList<string>();
            ArrayList2<int> data2 = new ArrayList2<int>();
            //int[] data = new int[] { };
            if (list != null)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    //product = new string[] { list[i].Description };
                    product2.Add(list[i].Description);
                    string sql2 = @"SELECT Description, RestockDate
                         FROM Product, Replenishment
                         WHERE Product.Id = Replenishment.ProductId AND Month(RestockDate)= {0} AND Description = '{1}'";
                    List<Product> list2 = DBUtl.GetList<Product>(sql2, month, list[i].Description);
                    data2.Add(list2.Count);
                    ViewData["Labels"] = product2;
                    ViewData["Data"] = data2;
                }
            }
            else
            {
                TempData["Message"] = "Record does not exist";
                TempData["MsgType"] = "warning";
                return RedirectToAction("trends");
            }

            string[] colors = new[] { "cyan", "pink" };
            ViewData["Chart"] = "bar";
            ViewData["Title"] = "Monthly Sales Summary";
            ViewData["ShowLegend"] = "false";
            //ViewData["Legend"] = "Product";
            ViewData["Colors"] = colors;
            return View("Chart");
        }
        #endregion
        public MainController(IWebHostEnvironment environment)
        {
            _env = environment;
        }
        private SelectList GetListDes()
        {
            // Get a list of all genres from the database
            var desSql = DBUtl.GetList("SELECT Id, Description FROM Product");
            SelectList lstProduct = new SelectList(desSql, "Id", "Description");
            return lstProduct;
        }

    }

    internal class ArrayList<T> : List<string>
    {
    }
    internal class ArrayList2<T> : List<int>
    {
    }


}
