﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using C300.Models;
using System.Security.Claims;
using Microsoft.AspNetCore.Http;
using System.IO;
using Microsoft.AspNetCore.Hosting;

namespace C300.Controllers
{
    public class ProductController : Controller
    {
        [AllowAnonymous]
        public IActionResult About()
        {
            return View();
        }
        [Authorize]
        public IActionResult ListProduct()
        {
            List<Product> product = DBUtl.GetList<Product>(
                  @"SELECT Product.Id, Description, Weight, Width, Height, Depth, Type, CategoryDescription, Isle, Shelf, Quantity, Image
                    FROM Product, Package, Category, Location 
                    WHERE Product.PackageId = Package.Id
                    AND Product.CategoryId = Category.Id
                    AND Product.LocationId = Location.Id"
                    );
            return View(product);

        }
        [Authorize]
        public IActionResult AddProduct()
        {
            ViewData["Category"] = GetListCat();
            ViewData["Package"] = GetListType();
            ViewData["Isle"] = GetListIsle();
            ViewData["Shelf"] = GetListShelf();
            return View();
        }
        [Authorize]
        [HttpPost]
        public IActionResult AddProduct(Product newProduct, IFormFile Image)
        {
            ModelState.Remove("Photo");
            if (!ModelState.IsValid)
            {
                ViewData["Category"] = GetListCat();
                ViewData["Package"] = GetListType();
                ViewData["Isle"] = GetListIsle();
                ViewData["Shelf"] = GetListShelf();
                ViewData["Message"] = "Invalid Input";
                ViewData["MsgType"] = "warning";
                return View(newProduct);
            }
            else
            {
                string picfilename = UploadFile(Image);
                string insert =
                   @"INSERT INTO Product(Description, Weight, Width, Height, Depth, PackageId, CategoryId, LocationId, Quantity, Image) 
                 VALUES('{0}', {1}, {2}, {3}, {4}, {5}, {6}, {7}, {8}, '{9}')";
                int result = DBUtl.ExecSQL(insert, newProduct.Description, newProduct.Weight, newProduct.Width,
                                           newProduct.Height, newProduct.Depth, newProduct.PackageId,
                                           newProduct.CategoryId,newProduct.LocationId, newProduct.Quantity, picfilename);  

                if (result == 1)
                {
                    TempData["Message"] = "Product Created";
                    TempData["MsgType"] = "success";
                }
                else
                {
                    TempData["Message"] = DBUtl.DB_Message;
                    TempData["MsgType"] = "danger";
                }
                return RedirectToAction("ListProduct");
            }
        }
        [Authorize]
        [HttpGet]
        public IActionResult EditProduct(int id)
        {
            string productSql = @"SELECT * FROM Product
                    WHERE Id = {0}";
            List<Product> lstProduct = DBUtl.GetList<Product>(productSql, id);

            if (lstProduct.Count == 1)
            {
                ViewData["Category"] = GetListCat();
                ViewData["Package"] = GetListType();
                ViewData["Isle"] = GetListIsle();
                ViewData["Shelf"] = GetListShelf();
                return View(lstProduct[0]);
            }
            else
            {
                TempData["Message"] = "Product not found.";
                TempData["MsgType"] = "warning";
                return RedirectToAction("ListProduct");
            }
        }
        [Authorize]
        [HttpPost]
        public IActionResult EditProduct(Product product, IFormFile Image)
        {
            ModelState.Remove("Photo");
            if (!ModelState.IsValid)
            {
                ViewData["Category"] = GetListCat();
                ViewData["Package"] = GetListType();
                ViewData["Isle"] = GetListIsle();
                ViewData["Shelf"] = GetListShelf();
                ViewData["Message"] = "Invalid Input";
                ViewData["MsgType"] = "danger";
                return View("EditProduct", product);
            }
            else
            {
                string picfilename = UploadFile(Image);
                string update = @"UPDATE Product 
                              SET Product.Weight={1}, Product.Width={2}, Product.Height={3}, Product.Depth={4}, PackageId={5},
                                  CategoryId = {6}, LocationId = {7} ,Quantity = {8}, Image = '{9}'              
                              WHERE Product.Id={0}";
                if (DBUtl.ExecSQL(update, product.Id,product.Weight,product.Width, product.Height,
                    product.Depth,product.PackageId,product.CategoryId,
                    product.LocationId,product.Quantity, picfilename)==1)

                {
                    TempData["Message"] = "Product Updated";
                    TempData["MsgType"] = "success";
                }
                else
                {
                    TempData["Message"] = DBUtl.DB_Message;
                    TempData["MsgType"] = "danger";
                }
                return RedirectToAction("ListProduct");
            }            
        }
        [Authorize]
        public IActionResult DeleteProduct(int id)
        {
            string select = @"SELECT * FROM Product 
                              WHERE Id={0}";
            DataTable ds = DBUtl.GetTable(select, id);
            if (ds.Rows.Count != 1)
            {
                TempData["Message"] = "Product record no longer exists.";
                TempData["MsgType"] = "warning";
            }
            else
            {
                string delete = "DELETE FROM Product WHERE Id={0}";
                int res = DBUtl.ExecSQL(delete, id);
                if (res == 1)
                {
                    TempData["Message"] = "Product Deleted";
                    TempData["MsgType"] = "success";
                }
                else
                {
                    TempData["Message"] = DBUtl.DB_Message;
                    TempData["MsgType"] = "danger";
                }
            }
            return RedirectToAction("ListProduct");
        }

        private SelectList GetListCat()
        {
            var catSql = DBUtl.GetList("SELECT Id, CategoryDescription FROM Category");
            SelectList lstCat = new SelectList(catSql, "Id", "CategoryDescription");
            return lstCat;
        }

        private SelectList GetListType()
        {
            
            var typeSql = DBUtl.GetList("SELECT Id, Type FROM Package");
            SelectList lstType = new SelectList(typeSql, "Id", "Type");
            return lstType;
        }

        private SelectList GetListIsle()
        {
            var isleSql = DBUtl.GetList("SELECT Id, Isle FROM Location");
            SelectList lstIsle = new SelectList(isleSql, "Id", "Isle");
            return lstIsle;
        }
        private SelectList GetListShelf()
        {
            var shelfSql = DBUtl.GetList("SELECT Id, Shelf FROM Location");
            SelectList lstShelf = new SelectList(shelfSql, "Id", "Shelf");
            return lstShelf;
        }
       
        public string UploadFile(IFormFile Image)
        {
            string fext = Path.GetExtension(Image.FileName);
            string uname = Guid.NewGuid().ToString();
            string fname = uname + fext;
            string fullpath = Path.Combine(_env.WebRootPath, "product/" + fname);
            FileStream fs = new FileStream(fullpath, FileMode.Create);
            Image.CopyTo(fs);
            fs.Close();
            return fname;

        }
        private IWebHostEnvironment _env;
        public ProductController(IWebHostEnvironment environment)
        {
            _env = environment;
        }
    }
}