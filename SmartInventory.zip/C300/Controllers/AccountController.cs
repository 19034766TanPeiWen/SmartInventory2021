using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Data;
using System.Security.Claims;
using C300.Models;
using Microsoft.AspNetCore.Authorization;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace C300.Controllers
{

    public class AccountController : Controller
    {
        private readonly IJwtAuth jwtAuth;
        private const string LOGIN_SQL =
           @"SELECT * FROM Employee
            WHERE EmployeeNo = '{0}' AND Password = HASHBYTES('SHA1', '{1}') AND CompanyId = {2}";

        private const string ROLE_COL = "UserRole";
        private const string NAME_COL = "LastName";

        private const string REDIRECT_CNTR = "Home";
        private const string REDIRECT_ACTN = "Index";

        [AllowAnonymous]
        public IActionResult UserLogin(string returnUrl = null)
        {

            List<SelectListItem> com = DBUtl.GetList<SelectListItem>(
                  @"SELECT DISTINCT Id As Value,
                                    TradingAs As Text
                                FROM Company
                                ORDER BY Id");
            ViewData["Company"] = GetListCom();
            TempData["ReturnUrl"] = returnUrl;
            return View();
        }

        [AllowAnonymous]
        [HttpPost]
        public IActionResult UserLogin(UserLogin user)
        {
            if (!AuthenticateUser(user.EmployeeNo, user.Password, user.CompanyId, out ClaimsPrincipal principal))
            {
                ViewData["Message"] = "Invalid Account";
                ViewData["MsgType"] = "warning";
                return View();
            }
            else
            {
                HttpContext.SignInAsync(
                   CookieAuthenticationDefaults.AuthenticationScheme,
                   principal,
               new AuthenticationProperties
               {
                   IsPersistent = user.RememberMe
               });
                string x = (string)TempData["returnUrl"];
                System.Diagnostics.Debug.WriteLine(x);
                if (TempData["returnUrl"] != null)
                {
                    string returnUrl = TempData["returnUrl"].ToString();
                    if (Url.IsLocalUrl(returnUrl))
                        return Redirect(returnUrl);
                }
                return RedirectToAction(REDIRECT_ACTN, REDIRECT_CNTR);
            }
        }

        [Authorize]
        public IActionResult Logoff(string returnUrl = null)
        {
            HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            if (Url.IsLocalUrl(returnUrl))
                return Redirect(returnUrl);
            return RedirectToAction("Index", "Home");
        }

        [AllowAnonymous]
        public IActionResult Forbidden()
        {
            return View();
        }

        [Authorize(Roles = "Manager")]
        public IActionResult Users()
        {
            List<UserDetails> list = DBUtl.GetList<UserDetails>(@"SELECT Employee.Id, EmployeeNo, LastName, GivenName,
                                                                OtherNames, Dob, TradingAs, UserRole
                                                                FROM Employee, Company
                                                                WHERE Employee.CompanyId = Company.Id");
            return View(list);
        }

        [Authorize(Roles = "Manager")]
        public IActionResult Delete(int id)
        {
            string delete = "DELETE FROM Employee WHERE Id={0}";
            int res = DBUtl.ExecSQL(delete, id);
            if (res == 1)
            {
                TempData["Message"] = "User Record Deleted";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }

            return RedirectToAction("Users");
        }

        [Authorize(Roles = "Manager")]
        [HttpGet]
        public IActionResult UserRegister()
        {

            ViewData["Company"] = GetListCom();
            return View("UserRegister");
        }

        [Authorize(Roles = "Manager")]
        [HttpPost]
        public IActionResult UserRegister(UserDetails usr)
        {
            ModelState.Remove("OtherNames");
            if (!ModelState.IsValid)
            {
                ViewData["Company"] = GetListCom();
                ViewData["Message"] = "Invalid Input";
                ViewData["MsgType"] = "warning";
                return View("UserRegister", usr);
            }
            else
            {
                string insert =
                   @"INSERT INTO Employee(EmployeeNo, LastName, GivenName, OtherNames, Dob, CompanyId, Password, UserRole) 
                VALUES('{0}', '{1}', '{2}', '{3}','{4:yyyy-MM-dd}',{5}, HASHBYTES('SHA1', '{6}'), '{7}')";
                if (DBUtl.ExecSQL(insert, usr.EmployeeNo, usr.LastName, usr.GivenName, usr.OtherNames, usr.Dob, usr.CompanyId, usr.Password, usr.UserRole) == 1)
                {
                    ViewData["Message"] = "Employee Successfully Registered";
                    ViewData["MsgType"] = "success";
                }
                else
                {
                    ViewData["Message"] = DBUtl.DB_Message;
                    ViewData["MsgType"] = "danger";
                }
                return RedirectToAction("UserLogin");
            }
        }

        [AllowAnonymous]
        public IActionResult VerifyUserID(string EmpId, int id)
        {
            string select = $"SELECT * FROM Employee WHERE Employee='{EmpId}' AND CompanyId={id}";
            if (DBUtl.GetTable(select).Rows.Count > 0)
            {
                return Json($"[{EmpId}] already in use");
            }
            return Json(true);
        }

        private bool AuthenticateUser(string empid, string pw, int id, out ClaimsPrincipal principal)
        {
            principal = null;

            string sql = @"SELECT * FROM Employee
            WHERE EmployeeNo = '{0}' AND Password = HASHBYTES('SHA1', '{1}') AND CompanyId = {2}";
            string select = String.Format(sql, empid, pw, id);
            DataTable ds = DBUtl.GetTable(select);
            if (ds.Rows.Count == 1)
            {
                principal =
                   new ClaimsPrincipal(
                      new ClaimsIdentity(
                         new Claim[] {
                        new Claim(ClaimTypes.NameIdentifier, empid),
                        new Claim(ClaimTypes.Name, ds.Rows[0][NAME_COL].ToString()),
                        new Claim(ClaimTypes.Role, ds.Rows[0][ROLE_COL].ToString())
                         },
                         CookieAuthenticationDefaults.AuthenticationScheme));

                return true;
            }
            return false;
        }

        //private bool AuthenticateUser(string empid, string pw, out ClaimsPrincipal principal)
        //{
        //    principal = null;

        //    string sql = @"SELECT * FROM Employee
        //    WHERE EmployeeNo = '{0}' AND Password ='{1}')";
        //    string select = String.Format(sql, empid, pw);
        //    DataTable ds = DBUtl.GetTable(select);
        //    if (ds.Rows.Count == 1)
        //    {
        //        var token = jwtAuth.Authentication(empid, pw);
        //        //principal =
        //        //   new ClaimsPrincipal(
        //        //      new ClaimsIdentity(
        //        //         new Claim[] {
        //        //        new Claim(ClaimTypes.NameIdentifier, empid),
        //        //        new Claim(ClaimTypes.Name, ds.Rows[0][NAME_COL].ToString()),
        //        //        new Claim(ClaimTypes.Role, ds.Rows[0][ROLE_COL].ToString())
        //        //         },
        //        //         CookieAuthenticationDefaults.AuthenticationScheme));
        //        if (token == null)
        //            return false;

        //        return true;
        //    }
        //    return false;
        //}
        //private readonly IJwtAuth jwtAuth;
        //public AccountController(IJwtAuth jwtAuth)
        //{
        //    this.jwtAuth = jwtAuth;
        //}

        private SelectList GetListCom()
        {

            var comSql = DBUtl.GetList("SELECT Id, TradingAs FROM Company");
            SelectList lstType = new SelectList(comSql, "Id", "TradingAs");
            return lstType;
        }
    }
}