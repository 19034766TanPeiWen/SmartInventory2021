﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using C300.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using System.IO;
using Microsoft.AspNetCore.Hosting;

namespace C300.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class LocationController : ControllerBase
    {
        // GET api/emotion
        [HttpGet]

        public IEnumerable<ProductMobile> Get()
        {
            List<ProductMobile> dbList = DBUtl.GetList<ProductMobile>("SELECT Product.Id, Description, Quantity, Image FROM Product, Location WHERE Product.LocationId = Location.Id");

            return dbList;
        }

        [HttpGet("{name}")]
        public IActionResult Get(string name)
        {
            string productSql = @"SELECT Product.Id, Description, Quantity, Image
                    FROM Product, Location 
                    WHERE Product.LocationId = Location.Id
                    AND Description = '{0}'";
            List<ProductMobile> dbList = DBUtl.GetList<ProductMobile>(productSql, name);
            if (dbList.Count > 0)
                return Ok(dbList);
            else
                return NotFound();
        }

        [HttpPost("upload", Name = "upload")]
        public IActionResult UploadFile([FromBody] ProductMobile newProduct, IFormFile Image)
        {
            if (newProduct == null)
            {
                return BadRequest();
            }
            string picfilename = DoPhotoUpload(Image);
            string sqlInsert = @"INSERT INTO Product(Description, Quantity, Image) 
                 VALUES('{0}', {1}, '{2}')";
            if (DBUtl.ExecSQL(sqlInsert, newProduct.Description, newProduct.Quantity, picfilename) == 1)
                return Ok();
            else
                return BadRequest(new { Message = DBUtl.DB_Message });
        }


        [HttpPut("{id}")]
        public IActionResult Put(string id, [FromBody] ProductMobile product, IFormFile Image)
        {
            if (product == null || id == null)
            {
                return BadRequest();
            }
            string picfilename = DoPhotoUpload(Image);
            string sql = @"UPDATE Product 
                              SET Quantity = {1}, Image = '{2}'             
                              WHERE Product.Id={0} 
                              AND Location.Id = Product.LocationId";
            string update = String.Format(sql, product.Id, product.Quantity, picfilename);
            if (DBUtl.ExecSQL(update) == 1)
                return Ok();
            else
                return BadRequest(new { Message = DBUtl.DB_Message });
        }


        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {

            string sql = @"DELETE Product 
                         WHERE Id={0}";
            string delete = String.Format(sql, id);
            if (DBUtl.ExecSQL(delete) == 1)
                return Ok();
            else
                return BadRequest(new { Message = DBUtl.DB_Message });

        }

        private string DoPhotoUpload(IFormFile photo)
        {
            string fext = Path.GetExtension(photo.FileName);
            string uname = Guid.NewGuid().ToString();
            string fname = uname + fext;
            string fullpath = Path.Combine(_env.WebRootPath, "product/" + fname);
            FileStream fs = new FileStream(fullpath, FileMode.Create);
            photo.CopyTo(fs);
            fs.Close();
            return fname;
        }
        private IWebHostEnvironment _env;
        public LocationController(IWebHostEnvironment environment)
        {
            _env = environment;
        }
    }
}

